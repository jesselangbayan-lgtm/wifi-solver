package com.example.dictportalhelper

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var connectivityManager: ConnectivityManager
    private lateinit var statusTextView: TextView
    private lateinit var checkButton: Button
    private lateinit var openPortalButton: Button
    private lateinit var startServiceButton: Button
    private lateinit var stopServiceButton: Button
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var serviceRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusTextView = findViewById(R.id.statusTextView)
        checkButton = findViewById(R.id.checkButton)
        openPortalButton = findViewById(R.id.openPortalButton)
        startServiceButton = findViewById(R.id.startServiceButton)
        stopServiceButton = findViewById(R.id.stopServiceButton)

        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        checkButton.setOnClickListener { triggerCaptivePortalCheck() }
        openPortalButton.setOnClickListener { openCaptivePortalSignIn() }
        startServiceButton.setOnClickListener { startBackgroundService() }
        stopServiceButton.setOnClickListener { stopBackgroundService() }

        setupNetworkCallback()
    }

    private fun setupNetworkCallback() {
        val networkRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasCaptivePortal = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)
                val isValidated = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

                runOnUiThread {
                    if (hasCaptivePortal) {
                        statusTextView.text = getString(R.string.status_captive)
                        try {
                            connectivityManager.bindProcessToNetwork(network)
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity,
                                getString(R.string.toast_bind_error, e.message ?: "unknown"),
                                Toast.LENGTH_SHORT).show()
                        }
                    } else if (isValidated) {
                        statusTextView.text = getString(R.string.status_validated)
                    } else {
                        statusTextView.text = getString(R.string.status_unvalidated)
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    statusTextView.text = getString(R.string.status_lost)
                }
            }
        }

        networkCallback?.let {
            connectivityManager.registerNetworkCallback(networkRequest, it)
        }
    }

    private fun triggerCaptivePortalCheck() {
        val activeNetwork = connectivityManager.activeNetwork
        if (activeNetwork == null) {
            Toast.makeText(this, getString(R.string.toast_no_network), Toast.LENGTH_SHORT).show()
            return
        }

        val caps = connectivityManager.getNetworkCapabilities(activeNetwork)
        if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) {
            statusTextView.text = getString(R.string.status_captive)
            openCaptivePortalSignIn()
        } else {
            Toast.makeText(this, getString(R.string.toast_no_portal), Toast.LENGTH_SHORT).show()
            statusTextView.text = getString(R.string.status_no_portal)
        }
    }

    private fun openCaptivePortalSignIn() {
        val activeNetwork = connectivityManager.activeNetwork ?: return
        try {
            val intent = Intent(ConnectivityManager.ACTION_CAPTIVE_PORTAL_SIGN_IN)
            intent.putExtra(ConnectivityManager.EXTRA_NETWORK, activeNetwork)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            Toast.makeText(this, getString(R.string.toast_opening_portal), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.toast_cant_open), Toast.LENGTH_SHORT).show()
        }
    }

    private fun startBackgroundService() {
        if (serviceRunning) return
        try {
            val intent = Intent(this, PortalDetectionService::class.java)
            startForegroundService(intent)
            serviceRunning = true
            startServiceButton.isEnabled = false
            stopServiceButton.isEnabled = true
            statusTextView.text = getString(R.string.status_service_running)
            Toast.makeText(this, getString(R.string.toast_service_started), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to start service: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopBackgroundService() {
        if (!serviceRunning) return
        try {
            val intent = Intent(this, PortalDetectionService::class.java)
            stopService(intent)
            serviceRunning = false
            startServiceButton.isEnabled = true
            stopServiceButton.isEnabled = false
            statusTextView.text = getString(R.string.status_service_stopped)
            Toast.makeText(this, getString(R.string.toast_service_stopped), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to stop service: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        networkCallback?.let {
            try {
                connectivityManager.unregisterNetworkCallback(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
