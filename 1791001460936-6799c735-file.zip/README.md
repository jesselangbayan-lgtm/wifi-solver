# DICT WiFi Portal Helper

Android utility that detects Wi-Fi captive portals (e.g. DICT Free WiFi) and helps
the user open the sign-in page. Background monitoring available via a foreground service.

## What was fixed vs the original source

- **Real portal launch.** `openCaptivePortalSignIn()` now fires the
  `ConnectivityManager.ACTION_CAPTIVE_PORTAL_SIGN_IN` intent with the network
  extra, so the actual sign-in page opens (not just a Toast).
- **Working foreground service.** `PortalDetectionService` now owns its own
  `ConnectivityManager.NetworkCallback`, updates the persistent notification
  with the current state, and survives the Activity.
- **`POST_NOTIFICATIONS` permission** added for Android 13+.
- **All strings externalized** to `strings.xml` (ready for Filipino/Tagalog).
- **Service start/stop buttons** added to the layout.
- **`viewBinding`** left enabled (compatible — no harm in keeping it on).

## Build & run

### A. Android Studio (recommended)

1. Open Android Studio (Hedgehog 2023.1.1 or newer).
2. **File → Open** → choose this folder (`DictPortalHelper`).
3. Let Gradle sync. Accept any SDK install prompts.
4. Plug in an Android device (USB debugging ON) or start an emulator.
5. Click **Run ▶** (Shift+F10).

### B. Command line

Requirements: JDK 17, Android SDK with platform-34 + build-tools 34.x.

```bash
cd DictPortalHelper
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

# Install:
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### C. GitHub Actions (cloud build)

See `.github/workflows/build.yml` — push to GitHub and the workflow builds
`app-debug.apk`. Download from the Actions → Artifacts tab.

## Permissions rationale

| Permission                          | Why                                                       |
|-------------------------------------|-----------------------------------------------------------|
| INTERNET                            | Test the captive portal redirect                          |
| ACCESS_NETWORK_STATE / WIFI       | Read `ConnectivityManager` capabilities                 |
| CHANGE_NETWORK_STATE              | Call `bindProcessToNetwork`                              |
| FOREGROUND_SERVICE (+             _DATA_SYNC)|         Run the persistent portal monitor in foreground |
| POST_NOTIFICATIONS (API 33+)      | Show the foreground-service notification                  |

## Tested APIs

- minSdk 24 (Android 7.0)
- compileSdk 34 (Android 14)
- Kotlin 1.9.24 / AGP 8.5.0
